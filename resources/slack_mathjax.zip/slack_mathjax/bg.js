chrome.browserAction.onClicked.addListener(function(tab) {
	// pass
});
